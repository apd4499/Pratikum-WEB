<!DOCTYPE html>
<html>
<head>
	<title>Belajar PHP</title>
</head>
<body>

	<h1>Array PHP</h1>

	<?php
		//------- tipe data array ------
		$kotak	= array('Mobil', 'Motor', 'Sepeda');
		$nama 	= ['Ajeng', 'Kipli', 'Joni'];


		print_r($kotak);
		echo $nama[0];

	?>

</body>
</html>