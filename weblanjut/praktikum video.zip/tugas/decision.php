<!DOCTYPE html>
<html>
<head>
	<title>Belajar PHP YOK</title>
</head>
<body>

	<h1>Logika di PHP</h1>

	<?php
	//--------- tipe data boolean -------
	// $hasil 	= true;
	// $hasil2	= false;

	//--------- if dan else ----------
	$password	= '1234';
	$password2	= '1234';

	if ( $password == $password2) {
		echo ' anda berhasil login ';
	}else{
		echo ' gagal! password yang anda masukan salah';
	}






	?>
</body>
</html>