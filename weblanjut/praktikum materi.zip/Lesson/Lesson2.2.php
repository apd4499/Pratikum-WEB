<?php
$i = 9;
do{
 echo "$i is"." <br>";
}
while($i < 9);
?>
